// Popup script for AI Sales Assistant extension

// DOM elements
const statusDot = document.getElementById('status-dot');
const statusText = document.getElementById('status-text');
const loginSection = document.getElementById('login-section');
const controlsSection = document.getElementById('controls-section');
const loginButton = document.getElementById('login-button');
const logoutButton = document.getElementById('logout-button');
const startCallButton = document.getElementById('start-call-button');
const stopCallButton = document.getElementById('stop-call-button');
const userName = document.getElementById('user-name');
const userEmail = document.getElementById('user-email');
const recordingTime = document.getElementById('recording-time');
const suggestionsCount = document.getElementById('suggestions-count');
const autoStartToggle = document.getElementById('auto-start');
const showTranscriptToggle = document.getElementById('show-transcript');
const showSuggestionsToggle = document.getElementById('show-suggestions');
const helpLink = document.getElementById('help-link');

// State variables
let isRecording = false;
let recordingInterval = null;
let recordingStartTime = null;
let currentSuggestionCount = 0;

// Initialize popup
document.addEventListener('DOMContentLoaded', () => {
  // Load settings
  loadSettings();
  
  // Check authentication status
  checkAuthStatus();
  
  // Set up event listeners
  setupEventListeners();
});

// Load user settings from storage
function loadSettings() {
  chrome.storage.local.get([
    'autoStart', 
    'showTranscript', 
    'showSuggestions'
  ], (result) => {
    autoStartToggle.checked = result.autoStart || false;
    showTranscriptToggle.checked = result.showTranscript !== false; // Default to true
    showSuggestionsToggle.checked = result.showSuggestions !== false; // Default to true
  });
}

// Save settings to storage
function saveSettings() {
  chrome.storage.local.set({
    autoStart: autoStartToggle.checked,
    showTranscript: showTranscriptToggle.checked,
    showSuggestions: showSuggestionsToggle.checked
  });
}

// Check if user is authenticated
function checkAuthStatus() {
  chrome.runtime.sendMessage({ action: 'checkAuth' }, (response) => {
    if (response && response.success) {
      if (response.authenticated) {
        // User is authenticated
        showAuthenticatedUI(response.user);
      } else {
        // User is not authenticated
        showUnauthenticatedUI();
      }
    } else {
      // Error checking auth status
      showUnauthenticatedUI();
      console.error('Error checking authentication status:', response?.error || 'Unknown error');
    }
  });
}

// Show UI for authenticated users
function showAuthenticatedUI(user) {
  loginSection.style.display = 'none';
  controlsSection.style.display = 'block';
  
  // Update status indicator
  statusDot.classList.add('connected');
  statusText.textContent = 'Connected';
  
  // Update user info
  userName.textContent = user.name || 'User';
  userEmail.textContent = user.email || '';
  
  // Check if recording is in progress
  chrome.storage.local.get(['isRecording', 'recordingStartTime', 'suggestionCount'], (result) => {
    if (result.isRecording) {
      isRecording = true;
      recordingStartTime = result.recordingStartTime;
      currentSuggestionCount = result.suggestionCount || 0;
      
      // Update UI for recording state
      startCallButton.disabled = true;
      stopCallButton.disabled = false;
      
      // Start timer
      startRecordingTimer();
      
      // Update suggestion count
      suggestionsCount.textContent = currentSuggestionCount;
    }
  });
}

// Show UI for unauthenticated users
function showUnauthenticatedUI() {
  loginSection.style.display = 'block';
  controlsSection.style.display = 'none';
  
  // Update status indicator
  statusDot.classList.remove('connected');
  statusText.textContent = 'Disconnected';
}

// Set up event listeners for UI controls
function setupEventListeners() {
  // Login button
  loginButton.addEventListener('click', () => {
    // Open login page in a new tab
    chrome.tabs.create({ url: 'http://localhost:3002/login?extension=true' });
  });
  
  // Logout button
  logoutButton.addEventListener('click', () => {
    // Clear auth data
    chrome.storage.local.remove(['authToken', 'userId', 'userEmail', 'userName'], () => {
      showUnauthenticatedUI();
    });
  });
  
  // Start call button
  startCallButton.addEventListener('click', () => {
    startRecording();
  });
  
  // Stop call button
  stopCallButton.addEventListener('click', () => {
    stopRecording();
  });
  
  // Settings toggles
  autoStartToggle.addEventListener('change', saveSettings);
  showTranscriptToggle.addEventListener('change', saveSettings);
  showSuggestionsToggle.addEventListener('change', saveSettings);
  
  // Help link
  helpLink.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: 'http://localhost:3002/help/extension' });
  });
}

// Start recording
function startRecording() {
  // Update UI
  startCallButton.disabled = true;
  stopCallButton.disabled = false;
  
  // Set recording state
  isRecording = true;
  recordingStartTime = Date.now();
  currentSuggestionCount = 0;
  
  // Store recording state
  chrome.storage.local.set({
    isRecording: true,
    recordingStartTime: recordingStartTime,
    suggestionCount: 0
  });
  
  // Start timer
  startRecordingTimer();
  
  // Reset suggestion count
  suggestionsCount.textContent = '0';
  
  // Send message to background script to start recording
  chrome.runtime.sendMessage({ action: 'startRecording' }, (response) => {
    if (!response || !response.success) {
      console.error('Error starting recording:', response?.error || 'Unknown error');
      stopRecording();
      alert('Could not start recording. Please try again.');
    }
  });
}

// Stop recording
function stopRecording() {
  // Update UI
  startCallButton.disabled = false;
  stopCallButton.disabled = true;
  
  // Clear recording state
  isRecording = false;
  
  // Clear storage
  chrome.storage.local.remove(['isRecording', 'recordingStartTime']);
  
  // Stop timer
  stopRecordingTimer();
  
  // Send message to background script to stop recording
  chrome.runtime.sendMessage({ action: 'stopRecording' });
}

// Start recording timer
function startRecordingTimer() {
  // Clear any existing interval
  if (recordingInterval) {
    clearInterval(recordingInterval);
  }
  
  // Update timer immediately
  updateRecordingTime();
  
  // Set interval to update timer every second
  recordingInterval = setInterval(updateRecordingTime, 1000);
}

// Stop recording timer
function stopRecordingTimer() {
  if (recordingInterval) {
    clearInterval(recordingInterval);
    recordingInterval = null;
  }
}

// Update recording time display
function updateRecordingTime() {
  if (!recordingStartTime) return;
  
  const elapsedMs = Date.now() - recordingStartTime;
  const seconds = Math.floor((elapsedMs / 1000) % 60);
  const minutes = Math.floor((elapsedMs / (1000 * 60)) % 60);
  const hours = Math.floor(elapsedMs / (1000 * 60 * 60));
  
  recordingTime.textContent = [
    hours.toString().padStart(2, '0'),
    minutes.toString().padStart(2, '0'),
    seconds.toString().padStart(2, '0')
  ].join(':');
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'updateSuggestionCount') {
    // Update suggestion count
    currentSuggestionCount = message.count;
    suggestionsCount.textContent = currentSuggestionCount;
    
    // Store updated count
    chrome.storage.local.set({ suggestionCount: currentSuggestionCount });
    
    sendResponse({ success: true });
  }
});