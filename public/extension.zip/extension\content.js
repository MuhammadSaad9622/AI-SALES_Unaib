// Content script for AI Sales Assistant extension

// Configuration
let isRecording = false;
let mediaRecorder = null;
let audioChunks = [];
let transcriptId = null;
let meetingInfo = {
  platform: '',
  title: '',
  participants: [],
  startTime: null
};

// UI elements
let aiSuggestionsPanel = null;
let transcriptionPanel = null;

// Initialize when content script loads
init();

function init() {
  console.log('AI Sales Assistant content script initialized');
  detectMeetingPlatform();
  setupMessageListeners();
  injectStyles();
}

// Detect which meeting platform we're on
function detectMeetingPlatform() {
  const url = window.location.href;
  
  if (url.includes('meet.google.com')) {
    meetingInfo.platform = 'Google Meet';
    meetingInfo.title = document.title.replace(' - Google Meet', '');
  } else if (url.includes('zoom.us')) {
    meetingInfo.platform = 'Zoom';
    meetingInfo.title = document.title.replace(' | Zoom', '');
  } else if (url.includes('teams.microsoft.com')) {
    meetingInfo.platform = 'Microsoft Teams';
    meetingInfo.title = document.title.replace(' | Microsoft Teams', '');
  }
  
  meetingInfo.startTime = new Date().toISOString();
  console.log('Detected meeting platform:', meetingInfo.platform);
}

// Set up listeners for messages from background script
function setupMessageListeners() {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Content script received message:', message);
    
    switch (message.action) {
      case 'startRecording':
        startRecording();
        sendResponse({ success: true });
        break;
        
      case 'stopRecording':
        stopRecording();
        sendResponse({ success: true });
        break;
        
      case 'updateSuggestions':
        updateSuggestions(message.suggestions);
        sendResponse({ success: true });
        break;
    }
    
    return true;
  });
}

// Inject CSS styles for our UI components
function injectStyles() {
  const styleElement = document.createElement('style');
  styleElement.textContent = `
    .ai-sales-assistant-panel {
      position: fixed;
      width: 300px;
      background-color: #ffffff;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      z-index: 9999;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      overflow: hidden;
      transition: all 0.3s ease;
    }
    
    .ai-sales-assistant-panel-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 16px;
      background-color: #0066cc;
      color: white;
    }
    
    .ai-sales-assistant-panel-title {
      font-weight: 600;
      font-size: 14px;
    }
    
    .ai-sales-assistant-panel-controls {
      display: flex;
      gap: 8px;
    }
    
    .ai-sales-assistant-panel-content {
      padding: 16px;
      max-height: 300px;
      overflow-y: auto;
    }
    
    .ai-suggestion {
      margin-bottom: 12px;
      padding: 10px;
      border-left: 3px solid #0066cc;
      background-color: #f0f7ff;
      border-radius: 4px;
    }
    
    .ai-suggestion-high {
      border-left-color: #ff3b30;
    }
    
    .ai-suggestion-medium {
      border-left-color: #ff9500;
    }
    
    .ai-suggestion-low {
      border-left-color: #34c759;
    }
    
    .ai-suggestion-text {
      font-size: 13px;
      line-height: 1.4;
    }
    
    .ai-suggestion-meta {
      display: flex;
      justify-content: space-between;
      font-size: 11px;
      color: #666;
      margin-top: 6px;
    }
    
    .transcript-text {
      font-size: 13px;
      line-height: 1.5;
      margin-bottom: 8px;
    }
    
    .transcript-speaker {
      font-weight: 600;
      color: #0066cc;
    }
    
    .control-button {
      background: none;
      border: none;
      cursor: pointer;
      color: white;
      padding: 4px;
      border-radius: 4px;
    }
    
    .control-button:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .recording-indicator {
      display: inline-block;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: #ff3b30;
      margin-right: 6px;
      animation: pulse 1.5s infinite;
    }
    
    @keyframes pulse {
      0% { opacity: 1; }
      50% { opacity: 0.5; }
      100% { opacity: 1; }
    }
  `;
  
  document.head.appendChild(styleElement);
}

// Create and show UI panels
function createUIElements() {
  // Create suggestions panel
  aiSuggestionsPanel = document.createElement('div');
  aiSuggestionsPanel.className = 'ai-sales-assistant-panel';
  aiSuggestionsPanel.style.right = '20px';
  aiSuggestionsPanel.style.top = '20px';
  
  aiSuggestionsPanel.innerHTML = `
    <div class="ai-sales-assistant-panel-header">
      <div class="ai-sales-assistant-panel-title">
        <span id="recording-indicator" class="recording-indicator" style="display: none;"></span>
        AI Suggestions
      </div>
      <div class="ai-sales-assistant-panel-controls">
        <button id="start-recording-btn" class="control-button" title="Start Recording">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="6" fill="white"/>
          </svg>
        </button>
        <button id="stop-recording-btn" class="control-button" title="Stop Recording" style="display: none;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="8" y="8" width="8" height="8" fill="white"/>
          </svg>
        </button>
        <button id="close-suggestions-btn" class="control-button" title="Close Panel">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M18 6L6 18M6 6L18 18" stroke="white" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </button>
      </div>
    </div>
    <div class="ai-sales-assistant-panel-content" id="suggestions-content">
      <div class="empty-state">Start recording to get AI suggestions</div>
    </div>
  `;
  
  // Create transcription panel
  transcriptionPanel = document.createElement('div');
  transcriptionPanel.className = 'ai-sales-assistant-panel';
  transcriptionPanel.style.right = '20px';
  transcriptionPanel.style.bottom = '20px';
  
  transcriptionPanel.innerHTML = `
    <div class="ai-sales-assistant-panel-header">
      <div class="ai-sales-assistant-panel-title">Live Transcription</div>
      <div class="ai-sales-assistant-panel-controls">
        <button id="close-transcript-btn" class="control-button" title="Close Panel">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M18 6L6 18M6 6L18 18" stroke="white" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </button>
      </div>
    </div>
    <div class="ai-sales-assistant-panel-content" id="transcript-content">
      <div class="empty-state">Transcription will appear here</div>
    </div>
  `;
  
  // Add panels to the page
  document.body.appendChild(aiSuggestionsPanel);
  document.body.appendChild(transcriptionPanel);
  
  // Set up event listeners for UI controls
  document.getElementById('start-recording-btn').addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'startRecording' });
  });
  
  document.getElementById('stop-recording-btn').addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'stopRecording' });
  });
  
  document.getElementById('close-suggestions-btn').addEventListener('click', () => {
    aiSuggestionsPanel.style.display = 'none';
  });
  
  document.getElementById('close-transcript-btn').addEventListener('click', () => {
    transcriptionPanel.style.display = 'none';
  });
  
  // Make panels draggable
  makeDraggable(aiSuggestionsPanel);
  makeDraggable(transcriptionPanel);
}

// Make an element draggable
function makeDraggable(element) {
  let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  element.querySelector('.ai-sales-assistant-panel-header').onmousedown = dragMouseDown;
  
  function dragMouseDown(e) {
    e.preventDefault();
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    document.onmousemove = elementDrag;
  }
  
  function elementDrag(e) {
    e.preventDefault();
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    element.style.top = (element.offsetTop - pos2) + "px";
    element.style.left = (element.offsetLeft - pos1) + "px";
    element.style.right = 'auto';
    element.style.bottom = 'auto';
  }
  
  function closeDragElement() {
    document.onmouseup = null;
    document.onmousemove = null;
  }
}

// Start recording audio
function startRecording() {
  if (isRecording) return;
  
  // Create UI if it doesn't exist yet
  if (!aiSuggestionsPanel) {
    createUIElements();
  }
  
  // Show panels if hidden
  aiSuggestionsPanel.style.display = 'block';
  transcriptionPanel.style.display = 'block';
  
  // Update UI for recording state
  document.getElementById('recording-indicator').style.display = 'inline-block';
  document.getElementById('start-recording-btn').style.display = 'none';
  document.getElementById('stop-recording-btn').style.display = 'inline-block';
  
  // Clear previous content
  document.getElementById('suggestions-content').innerHTML = '<div class="empty-state">Listening for conversation...</div>';
  document.getElementById('transcript-content').innerHTML = '';
  
  // Start audio recording
  navigator.mediaDevices.getUserMedia({ audio: true })
    .then(stream => {
      isRecording = true;
      audioChunks = [];
      
      mediaRecorder = new MediaRecorder(stream);
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunks.push(event.data);
          processAudioChunk(event.data);
        }
      };
      
      mediaRecorder.onstop = () => {
        const tracks = stream.getTracks();
        tracks.forEach(track => track.stop());
        
        // Process complete recording
        const completeAudio = new Blob(audioChunks, { type: 'audio/webm' });
        sendCompleteAudioForProcessing(completeAudio);
      };
      
      // Start recording with 5-second intervals for real-time processing
      mediaRecorder.start(5000);
      
      console.log('Recording started');
    })
    .catch(error => {
      console.error('Error starting recording:', error);
      alert('Could not access microphone. Please check permissions.');
    });
}

// Stop recording
function stopRecording() {
  if (!isRecording || !mediaRecorder) return;
  
  isRecording = false;
  mediaRecorder.stop();
  
  // Update UI
  document.getElementById('recording-indicator').style.display = 'none';
  document.getElementById('start-recording-btn').style.display = 'inline-block';
  document.getElementById('stop-recording-btn').style.display = 'none';
  
  console.log('Recording stopped');
}

// Process audio chunk for real-time transcription
function processAudioChunk(audioChunk) {
  // Convert audio chunk to base64
  const reader = new FileReader();
  reader.readAsDataURL(audioChunk);
  
  reader.onloadend = () => {
    const base64Audio = reader.result.split(',')[1];
    
    // Send to background script for processing
    chrome.runtime.sendMessage({
      action: 'processTranscript',
      transcript: {
        audio: base64Audio,
        format: 'webm',
        partial: true
      },
      meetingInfo: meetingInfo
    }, response => {
      if (response && response.success) {
        // Update transcript panel with new text
        updateTranscript(response.data.transcript);
        
        // Store transcript ID for fetching suggestions
        if (response.data.transcriptId) {
          transcriptId = response.data.transcriptId;
          // Fetch suggestions based on this transcript
          fetchSuggestions();
        }
      } else {
        console.error('Error processing audio chunk:', response?.error || 'Unknown error');
      }
    });
  };
}

// Send complete audio recording for final processing
function sendCompleteAudioForProcessing(audioBlob) {
  const reader = new FileReader();
  reader.readAsDataURL(audioBlob);
  
  reader.onloadend = () => {
    const base64Audio = reader.result.split(',')[1];
    
    // Send to background script for processing
    chrome.runtime.sendMessage({
      action: 'processTranscript',
      transcript: {
        audio: base64Audio,
        format: 'webm',
        partial: false
      },
      meetingInfo: meetingInfo
    }, response => {
      if (response && response.success) {
        console.log('Complete audio processed successfully');
        // Final update to transcript
        updateTranscript(response.data.transcript);
        // Get final suggestions
        fetchSuggestions();
      } else {
        console.error('Error processing complete audio:', response?.error || 'Unknown error');
      }
    });
  };
}

// Fetch AI suggestions based on transcript
function fetchSuggestions() {
  if (!transcriptId) return;
  
  chrome.runtime.sendMessage({
    action: 'getSuggestions',
    transcriptId: transcriptId
  }, response => {
    if (response && response.success) {
      updateSuggestions(response.suggestions);
    } else {
      console.error('Error fetching suggestions:', response?.error || 'Unknown error');
    }
  });
}

// Update the suggestions panel with new suggestions
function updateSuggestions(suggestions) {
  if (!suggestions || suggestions.length === 0) return;
  
  const suggestionsContent = document.getElementById('suggestions-content');
  suggestionsContent.innerHTML = '';
  
  suggestions.forEach(suggestion => {
    const priorityClass = suggestion.priority === 'high' ? 'ai-suggestion-high' : 
                         suggestion.priority === 'medium' ? 'ai-suggestion-medium' : 
                         'ai-suggestion-low';
    
    const suggestionElement = document.createElement('div');
    suggestionElement.className = `ai-suggestion ${priorityClass}`;
    suggestionElement.innerHTML = `
      <div class="ai-suggestion-text">${suggestion.text}</div>
      <div class="ai-suggestion-meta">
        <span>${suggestion.type}</span>
        <span>${Math.round(suggestion.confidence * 100)}% confidence</span>
      </div>
    `;
    
    suggestionsContent.appendChild(suggestionElement);
  });
}

// Update the transcript panel with new text
function updateTranscript(transcript) {
  if (!transcript || !transcript.text) return;
  
  const transcriptContent = document.getElementById('transcript-content');
  
  // If transcript has speaker information
  if (transcript.speaker) {
    const transcriptElement = document.createElement('div');
    transcriptElement.className = 'transcript-text';
    transcriptElement.innerHTML = `<span class="transcript-speaker">${transcript.speaker}:</span> ${transcript.text}`;
    transcriptContent.appendChild(transcriptElement);
  } else {
    // Simple text without speaker info
    const transcriptElement = document.createElement('div');
    transcriptElement.className = 'transcript-text';
    transcriptElement.textContent = transcript.text;
    transcriptContent.appendChild(transcriptElement);
  }
  
  // Auto-scroll to bottom
  transcriptContent.scrollTop = transcriptContent.scrollHeight;
}