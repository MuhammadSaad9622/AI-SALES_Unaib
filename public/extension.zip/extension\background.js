// Background script for AI Sales Assistant extension

// Configuration
const API_BASE_URL = 'http://localhost:3002/api'; // Server running on port 3002
let authToken = null;
let userId = null;

// Initialize extension
chrome.runtime.onInstalled.addListener(() => {
  console.log('AI Sales Assistant extension installed');
  // Check if user is already authenticated
  chrome.storage.local.get(['authToken', 'userId'], (result) => {
    if (result.authToken && result.userId) {
      authToken = result.authToken;
      userId = result.userId;
      console.log('User already authenticated');
    }
  });
});

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Background received message:', message);

  switch (message.action) {
    case 'authenticate':
      handleAuthentication(message.token, message.user)
        .then(result => sendResponse(result))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true; // Required for async sendResponse

    case 'startRecording':
      sendResponse({ success: true, message: 'Recording started' });
      // Notify content script to start recording
      chrome.tabs.sendMessage(sender.tab.id, { action: 'startRecording' });
      return false;

    case 'stopRecording':
      sendResponse({ success: true, message: 'Recording stopped' });
      // Notify content script to stop recording
      chrome.tabs.sendMessage(sender.tab.id, { action: 'stopRecording' });
      return false;

    case 'processTranscript':
      processTranscript(message.transcript, message.meetingInfo)
        .then(result => sendResponse(result))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true; // Required for async sendResponse

    case 'getSuggestions':
      fetchSuggestions(message.transcriptId)
        .then(result => sendResponse(result))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true; // Required for async sendResponse

    case 'checkAuth':
      checkAuthentication()
        .then(result => sendResponse(result))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true; // Required for async sendResponse

    default:
      sendResponse({ success: false, error: 'Unknown action' });
      return false;
  }
});

// Handle user authentication
async function handleAuthentication(token, user) {
  try {
    if (!token || !user) {
      throw new Error('Invalid authentication data');
    }

    // Store authentication data
    authToken = token;
    userId = user.id;

    // Save to local storage
    chrome.storage.local.set({ 
      authToken: token, 
      userId: user.id,
      userEmail: user.email,
      userName: user.name
    });

    // Track extension installation/authentication
    await fetch(`${API_BASE_URL}/events/track`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        eventType: 'extension_auth',
        userId: user.id,
        metadata: {
          timestamp: new Date().toISOString(),
          browser: navigator.userAgent
        }
      })
    });

    return { success: true, message: 'Authentication successful' };
  } catch (error) {
    console.error('Authentication error:', error);
    return { success: false, error: error.message };
  }
}

// Check if user is authenticated
async function checkAuthentication() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['authToken', 'userId', 'userEmail', 'userName'], (result) => {
      if (result.authToken && result.userId) {
        authToken = result.authToken;
        userId = result.userId;
        resolve({ 
          success: true, 
          authenticated: true,
          user: {
            id: result.userId,
            email: result.userEmail,
            name: result.userName
          }
        });
      } else {
        resolve({ success: true, authenticated: false });
      }
    });
  });
}

// Process transcript from content script
async function processTranscript(transcript, meetingInfo) {
  try {
    if (!authToken || !userId) {
      throw new Error('User not authenticated');
    }

    // Send transcript to API for processing
    const response = await fetch(`${API_BASE_URL}/transcripts/process`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({
        transcript: transcript,
        userId: userId,
        meetingInfo: meetingInfo
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Failed to process transcript');
    }

    const data = await response.json();
    return { success: true, data };
  } catch (error) {
    console.error('Process transcript error:', error);
    return { success: false, error: error.message };
  }
}

// Fetch AI suggestions based on transcript
async function fetchSuggestions(transcriptId) {
  try {
    if (!authToken) {
      throw new Error('User not authenticated');
    }

    // Get suggestions from API
    const response = await fetch(`${API_BASE_URL}/ai/suggestions?transcriptId=${transcriptId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${authToken}`
      }
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Failed to fetch suggestions');
    }

    const data = await response.json();
    return { success: true, suggestions: data.suggestions };
  } catch (error) {
    console.error('Fetch suggestions error:', error);
    return { success: false, error: error.message };
  }
}